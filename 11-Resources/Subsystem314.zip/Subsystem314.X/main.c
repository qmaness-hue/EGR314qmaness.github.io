#include <xc.h>

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/system/interrupt.h"
#include "mcc_generated_files/timer/tmr1.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/uart/uart2.h"

// ================= CONFIG =================
#define my_id 'Q'

#define STEP_HIGH1()    IO_RF0_SetHigh()
#define STEP_LOW1()     IO_RF0_SetLow()

#define STEP_HIGH2()    IO_RC2_SetHigh()
#define STEP_LOW2()     IO_RC2_SetLow()

#define DIR_FORWARD1()  IO_RA6_SetHigh()
#define DIR_REVERSE1()  IO_RA6_SetLow()

#define DIR_FORWARD2()  IO_RB5_SetHigh()
#define DIR_REVERSE2()  IO_RB5_SetLow()


// ===== LED DEFINITIONS =====
#define LED_YELLOW_ON()   IO_RA3_SetHigh()
#define LED_YELLOW_OFF()  IO_RA3_SetLow()
#define LED_YELLOW_TOGGLE()  IO_RA3_Toggle()

#define LED_RED_ON()      IO_RF3_SetHigh()
#define LED_RED_OFF()     IO_RF3_SetLow()
#define LED_RED_TOGGLE()  IO_RF3_Toggle()

#define LED_BLUE_ON()     IO_RC0_SetHigh()
#define LED_BLUE_OFF()    IO_RC0_SetLow()
#define LED_BLUE_TOGGLE()  IO_RC0_Toggle()


#define BUFSIZE 16
#define MSGSIZE 64
#define TEAMSIZE 3
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

uint16_t ms=0;

uint16_t sec=0;
uint16_t sec_01 = 0;


// ================= UART BUFFER =================
char rx_buffer[MSGSIZE];
uint8_t rx_index = 0;

// ================= TIMER =================
    char c=0;
    char buffer_in[BUFSIZE+1];
    char message_in[MSGSIZE+1];
    char message_out[MSGSIZE+1];
    unsigned int message_incoming=0;
    bool SENDFORWARD = false; 

    const char team_ids[TEAMSIZE+1]="XQRD";
    
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    
    void blink_leds(void)
    {
        LED_BLUE_ON();
        LED_RED_ON();
        
    }

void timer_callback(void)
{
    ms++;
    
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
        sec_01++;
        LED_YELLOW_TOGGLE();
    }
}

// ================= UART TX =================
void UART1_SendString(const char *str)
{
    while (*str)
    {
        while (!UART1_IsTxReady());
        UART1_Write(*str++);
    }
}

// ================= ERROR =================
void send_error(void)
{
    UART1_SendString("ERROR: ");
    LED_BLUE_OFF();
    LED_RED_OFF();
    
    LED_BLUE_TOGGLE();
    LED_RED_TOGGLE();
    __delay_ms(1000);
    LED_BLUE_TOGGLE();
    LED_RED_TOGGLE();
    
}

// ================= MOTOR =================
void motor_forward(void)
{
    DIR_FORWARD1();
    DIR_FORWARD2();
    LED_RED_TOGGLE();
}

void motor_reverse(void)
{
    DIR_REVERSE1();
    DIR_REVERSE2();
    LED_BLUE_TOGGLE();
}

uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}

void fill_string(char * mystring,char value,unsigned int size)
    {
    for (int ii=0;ii<size;ii++)
    {
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
//        printf("%c,%c;",value,mystring[ii]);
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii)
{
    // Null terminate message BEFORE "YB"
    message_in[ii-2] = '\0';

    // message format: AZ R Q command
    char sender   = message_in[2];
    char receiver = message_in[3];
    char *data = &message_in[4];
    
    // Only act if message is for me
    if (receiver == my_id)
    {    
        //blink_leds();
        if (strcmp(data, "forward") == 0)
        {
            motor_forward();
        }
        else if (strcmp(data, "reverse") == 0)
        {
            motor_reverse();
        }
        else
        {
            send_error();
            printf("Unknown Command");
        }
    }

    // Optional: print message for debugging
    printf("%sYB", message_in);
}
// ================= PROCESS MESSAGE =================
void UART2_Task(void)
    {
    if(UART2_IsRxReady())
        {
            c = UART2_Read();
            // DEBUG: echo every received char
           
            //UART1_Write(c);
            //printf("%c,%u,%u,%u,%u",c,buffer_last_ii,buffer_ii,message_ii,message_incoming);
            buffer_in[buffer_ii]=c;
            //blink_leds();
            
            //printf("AZAXTESTYB");
            
            //PROCESSING MESSAGE's START
            if(buffer_in[buffer_last_ii]=='A' && buffer_in[buffer_ii]=='Z'){
                printf("AZ Start");
                
                fill_string(message_in,'_',MSGSIZE);
                message_in[MSGTESTSIZE]=MSGTESTCHAR;
                message_incoming=1;
                
              

                
                message_in[0] = buffer_in[buffer_last_ii];
                message_ii=1;
                //blink_leds();
               
            }
            
            //PROCESSING MESSAGE's END
            if (buffer_in[buffer_last_ii]=='Y' && buffer_in[buffer_ii]=='B'){
                //printf("AZAAPICRECEIVEDYB");
                
                message_incoming=0;
                message_in[message_ii] = buffer_in[buffer_ii];
                message_last_ii= message_ii;
                message_ii = message_ii+1;
                //blink_leds();
                //handle_message(message_ii);
               
                
                handle_message(message_ii);
                }
            }
            
            if (message_incoming!=0){
                message_in[message_ii] = buffer_in[buffer_ii];
                //blink_leds();
                
                //analyzing SENDER ID
                if (message_ii==2){
                    //blink_leds();
                    unsigned result = 0;
                    char x=0;
                    x = message_in[message_ii];
                    result= find_char(team_ids,x,TEAMSIZE);
                    if (result==0){
                        //printf("AZbaPIC: sender not in teamYB");
                        send_error();
                        printf("Sender:%c",x);
                        //message_incoming=0;
                        //message_ii=0;
                        //blink_leds();
                    } else {
                        //blink_leds();
                        printf("sender in team");
                        char me = my_id;
                        //IF I AM THE SENDER, THEN THE MESSAGE HAS NO SENSE
                        if(me == x){
                            message_incoming=0;
                            message_ii=0;
                        }
                    }
                }

                //analyzing RECEIVER ID
                if (message_ii==3){
                    //blink_leds();
                    unsigned result = 0;
                    char d=0;
                    d = message_in[message_ii];
                    result= find_char(team_ids,d,TEAMSIZE);
                    if (result==0){
                        send_error();
                        printf("Receiver not in teamYB");
                        message_incoming=0;
                        message_ii=0;
                    } else {
                        //printf("AZbaPIC: receiver in teamYB");
                        //IF THE MESSAGE IS SUPPOSED TO BE RECEIVED BY ME, THEN
                        if(my_id == d){
                            SENDFORWARD = false;
                            
                        }
                        else
                        {
                            //Message is supposed to be received by somebody else
                            SENDFORWARD = true;
                            
                        }
                    }
                }

                              
                message_last_ii= message_ii;
                message_ii = message_ii+1;
                if (message_ii<MSGTESTSIZE){} else{
                    //blink_leds();
                    send_error();
                    printf("AZbaPIC: message too large. deletingYB");
                    message_incoming=0;
                    message_ii=0;
                }
            }
            buffer_last_ii= buffer_ii;
            buffer_ii = (buffer_ii+1)%BUFSIZE;
            
            
            
//          printf("%s,%s",buffer_in,message_in);
        }
    




int main(void)
{
    SYSTEM_Initialize();

    INTERRUPT_GlobalInterruptEnable();
    //INTERRUPT_PeripheralInterruptEnable();

    // Timer
    TMR1_Initialize();
    TMR1_OverflowCallbackRegister(timer_callback);
    TMR1_Start();

    // UART
    UART1_Initialize();   // TX
    UART1_Enable();
    UART1_TransmitEnable();

    UART2_Initialize();   // RX
    UART2_Enable();
    UART2_ReceiveEnable();

    char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;

    uint16_t ms_last=0;
    uint16_t sec_last=0;

    
    __delay_ms(1000);

    // ===== TEST =====

    while (1)
    {
        //UART1_SendString("AZRQblehYB");
        //strcpy(message_in, "AZRQforward");
        //handle_message(strlen(message_in)+2);
        __delay_ms(500);
        UART2_Task();
    }
}